var searchData=
[
  ['add_0',['add',['../class_my_class.html#a9598cdb7b4456bf20ddad506954acece',1,'MyClass.add(int a, int b)'],['../class_my_class.html#a7d55304896d9843f0bb4aebba657fa08',1,'MyClass.add(String a, String b)']]]
];
