var searchData=
[
  ['sayhello_0',['sayHello',['../class_my_class.html#a001a9102122ad9b5ee8cdf54d6010e9d',1,'MyClass']]],
  ['sub_1',['sub',['../class_my_class.html#a5a2e0fdb8418d7cb64a5e1a56d2da99c',1,'MyClass']]]
];
