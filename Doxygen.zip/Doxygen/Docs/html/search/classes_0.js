var searchData=
[
  ['myclass_0',['MyClass',['../class_my_class.html',1,'']]]
];
