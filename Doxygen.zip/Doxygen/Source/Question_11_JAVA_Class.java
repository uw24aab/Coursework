/**
 * MyClass provides basic arithmetic operations and string manipulation methods.
 * This class includes methods for addition, subtraction, multiplication, 
 * division, modulus operations, and a greeting method.
 */
public class MyClass {

    /**
     * Adds two integers.
     *
     * @param a the first integer
     * @param b the second integer
     * @return the sum of a and b
     */
    public int add(int a, int b) {
        return a + b;
    }

    /**
     * Concatenates two strings.
     *
     * @param a the first string
     * @param b the second string
     * @return the concatenated result of a and b
     */
    public String add(String a, String b) {
        return a + b;
    }

    /**
     * Subtracts the second integer from the first.
     *
     * @param a the minuend
     * @param b the subtrahend
     * @return the difference of a and b
     */
    public int sub(int a, int b) {
        return a - b;
    }

    /**
     * Multiplies two integers.
     *
     * @param a the first integer
     * @param b the second integer
     * @return the product of a and b
     */
    public int mult(int a, int b) {
        return a * b;
    }

    /**
     * Divides the first integer by the second. Note: does not handle division by zero.
     *
     * @param a the dividend
     * @param b the divisor
     * @return the quotient of a and b
     */
    public int div(int a, int b) {
        return a / b;
    }

    /**
     * Calculates the modulus of two integers.
     *
     * @param a the dividend
     * @param b the divisor
     * @return the remainder when a is divided by b
     */
    public int mod(int a, int b) {
        return a % b;
    }

    /**
     * Returns a greeting message for the specified name.
     *
     * @param name the name of the person to greet
     * @return a greeting message including the name
     */
    public String sayHello(String name) {
        return "Hello " + name;
    }
}